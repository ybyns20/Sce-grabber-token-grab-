import os
import sys
from time import sleep
from zipfile import ZipFile
import requests

class MiseAJour:
    def __init__(self):
        self.version = '1.5.8'
        self.github = 'https://github.com/ybyns20'
        self.verifier_mise_a_jour()

    def verifier_mise_a_jour(self):
        code = requests.get(self.github).text
        if f"self.version = '{self.version}'" in code:
            print('Cette version est à jour !')
            sleep(1)
            print('Vous pouvez maintenant ouvrir builder.pyw pour ouvrir le constructeur !')
            sleep(1)
            print('Quitter...')
            sleep(2)
            sys.exit()
        else:
            print('''
                    ███╗   ██╗███████╗██╗    ██╗    ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗██╗
                    ████╗  ██║██╔════╝██║    ██║    ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██║
                    ██╔██╗ ██║█████╗  ██║ █╗ ██║    ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗  ██║
                    ██║╚██╗██║██╔══╝  ██║███╗██║    ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝  ╚═╝
                    ██║ ╚████║███████╗╚███╔███╔╝    ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗██╗
                    ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝      ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝
                                      Votre version de Sce Team Token Grab est obsolète !''')
            choix = input('\nVoulez-vous effectuer une mise à jour ? (o/n): ')
            if choix.lower() == 'o':
                nouvelle_version_source = requests.get(self.github)
                with open("Sce-Team-Token-Grab.zip", 'wb') as zipfile:
                    zipfile.write(nouvelle_version_source.content)
                with ZipFile("Sce-Team-Token-Grab.zip", 'r') as filezip:
                    filezip.extractall(path=os.path.join(os.path.expanduser("~"), "Téléchargements"))
                os.remove("Sce-Team-Token-Grab.zip")
                print('La nouvelle version est maintenant dans votre dossier Téléchargements.\nMise à jour terminée !')
                print("Quitter...")
                sleep(5)
                sys.exit()
            if choix.lower() == 'n':
                print('Quitter...')
                sleep(2)
                sys.exit()

if __name__ == '__main__':
    MiseAJour()